#!/bin/bash
#-*- coding: utf-8 -*-
echo "-----Modify annotation files start-----"

__author__ = 'zhangheting'

#������Ҫɾ���ĳ�Ա����
CUSTOM="zhangheting@wind-mobi.com pengfugen@wind-mobi.com wangyan@wind-mobi.com yaohua@wind-mobi.com tuwenzan@wind-mobi.com"

for people in $CUSTOM;do
   sed -i "s/$people/test@126.com/g" `grep "$people" -rl ./wind`
done

echo "-----Modify annotation files finish-----"